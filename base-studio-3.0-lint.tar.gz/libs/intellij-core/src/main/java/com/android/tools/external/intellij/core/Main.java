package com.android.tools.external.intellij.core;

/**
 * This is a dummy place-holder class for the PSI library
 * used by lint. The bytecode for this library is not generated
 * from source; it's unzipped from prebuilts.
 */
public class Main {
    public static void main(String[] args) {
        // This class is here to make the packaging and javadoc tasks happy
    }
}
